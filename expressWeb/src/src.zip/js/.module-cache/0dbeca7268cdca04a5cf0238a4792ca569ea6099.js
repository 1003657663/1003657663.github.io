/**
 * Created by songchao on 16/6/17.
 */
/**
 * 右边容器
 */
var Right = React.createClass({displayName: "Right",
    render: function () {
        return (
            React.createElement("div", {className: "hidden-xs col-sm-3 col-md-4 right-component"})
        );
    }
});