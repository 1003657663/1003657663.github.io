$(document).ready(function () {
    $("#CalendarMain").remove();
})